#include "motorlib.hpp"
#include <stdlib.h>


int main(int argc, char ** argv){

  srand(1);
  lanzar_motor_grafico(argc, argv);

  exit(EXIT_SUCCESS);
}
