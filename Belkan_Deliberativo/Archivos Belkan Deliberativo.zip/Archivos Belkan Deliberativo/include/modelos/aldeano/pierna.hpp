#ifndef PIERNAALDEANO3D_HPP
#define PIERNAALDEANO3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class PiernaAldeano3D : public Objeto3D{
private:

public:
  PiernaAldeano3D();
  ~PiernaAldeano3D();

};

#endif
