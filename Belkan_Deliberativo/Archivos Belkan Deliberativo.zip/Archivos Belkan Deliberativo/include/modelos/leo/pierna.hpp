#ifndef PIERNALEO3D_HPP
#define PIERNALEO3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class PiernaLeo3D : public Objeto3D{
private:

public:
  PiernaLeo3D();
  ~PiernaLeo3D(){}

};

#endif
