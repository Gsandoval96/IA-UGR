#ifndef BRAZOREY3D_HPP
#define BRAZOREY3D_HPP

#include "obj3dlib.hpp"
#include <string.h>


class BrazoRey3D : public Objeto3D{
private:

public:
  BrazoRey3D();
  ~BrazoRey3D();

};

#endif
