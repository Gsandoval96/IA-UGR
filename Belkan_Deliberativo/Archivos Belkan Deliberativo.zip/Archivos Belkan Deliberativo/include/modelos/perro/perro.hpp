#ifndef PERRO_H
#define PERRO_H

#include "obj3dlib.hpp"
#include "modelos/perro/cabeza.hpp"
#include "modelos/perro/lomo.hpp"

class Perro3D : public Objeto3D {
private:
  /* data */
public:
  Perro3D();
  ~Perro3D();

};

#endif
