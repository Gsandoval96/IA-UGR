#ifndef ITEM_H
#define ITEM_H

#include "obj3dlib.hpp"


class Item3D : public Objeto3D {
private:
  /* data */
public:
  Item3D();
  ~Item3D();

};

#endif
