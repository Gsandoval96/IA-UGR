#ifndef PUERTA_H
#define PUERTA_H

#include "obj3dlib.hpp"


class Puerta3D : public Objeto3D {
private:
  /* data */
public:
  Puerta3D();
  ~Puerta3D();

};

#endif
